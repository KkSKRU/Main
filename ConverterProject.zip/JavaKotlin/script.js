// Convert a string to UpperCamelCase format 
function toUpperCamelCase(str) {
  return str
    .replace(/(^|_|\-|\s)+(.)/g, (_, __, chr) => chr.toUpperCase())
    .replace(/[^a-zA-Z0-9]/g, '');
}

// Convert a string to lowerCamelCase format 
function toLowerCamelCase(str) {
  const upper = toUpperCamelCase(str);
  return upper.charAt(0).toLowerCase() + upper.slice(1);
}

// Determine the appropriate Java type for a given JavaScript value and field name
function determineJavaType(fieldName, value) {
  const forcePrimitives = document.getElementById("force-primitives").checked;
  const lowerField = fieldName.toLowerCase();
  const isDateTimeField = lowerField.includes("time") || lowerField.includes("date");

  if (value === null || value === undefined) return "Object";

  if (Array.isArray(value)) {
    if (value.length === 0) return "List<Object>";
    const elementType = determineJavaType(fieldName, value[0]);
    return `List<${elementType}>`;
  }

  if (typeof value === "boolean") return forcePrimitives ? "boolean" : "Boolean";

  if (typeof value === "number") {
    if (Number.isInteger(value)) {
      if (isDateTimeField) return forcePrimitives ? "long" : "Long";
      return value >= -2147483648 && value <= 2147483647
        ? (forcePrimitives ? "int" : "Integer")
        : (forcePrimitives ? "long" : "Long");
    }
    return forcePrimitives ? "double" : "Double";
  }

  if (typeof value === "string") return "String";

  if (typeof value === "object") return "Object";

  return "Object";
}

// Determine the appropriate Kotlin type for a given value and field name
function determineKotlinType(fieldName, value) {
  const forceNonNull = document.getElementById("force-non-null").checked;
  const lowerField = fieldName.toLowerCase();
  const isDateTimeField = lowerField.includes("time") || lowerField.includes("date");

  let type = "Any";

  if (value === null || value === undefined) {
    type = "Any";
  } else if (Array.isArray(value)) {
    if (value.length === 0) {
      type = "List<Any>";
    } else {
      const elementType = determineKotlinType(fieldName, value[0]);
      type = `List<${elementType}>`;
    }
  } else if (typeof value === "boolean") {
    type = "Boolean";
  } else if (typeof value === "number") {
    if (Number.isInteger(value)) {
      type = isDateTimeField ? "Long" : "Int";
    } else {
      type = "Double";
    }
  } else if (typeof value === "string") {
    type = "String";
  } else if (typeof value === "object") {
    type = "Any";
  }

  return forceNonNull ? type : `${type}?`;
}

// Generate Java class code from a JSON object
function generateJavaCode(obj, className = "Root") {
  const useRecord = document.getElementById("record-classes").checked;
  const classNameUpper = toUpperCamelCase(className);
  const fields = [];

  // Process each key/value pair to define fields
  for (const key in obj) {
    const val = obj[key];
    const fieldName = toLowerCamelCase(key);
    const fieldType = determineJavaType(key, val);
    fields.push({ fieldName, fieldType });
  }

  if (useRecord) {
    // Generate record class syntax
    const recordFields = fields.map(f => `${f.fieldType} ${f.fieldName}`).join(", ");
    return `public record ${classNameUpper}(${recordFields}) {}\n`;
  } else {
    // Generate traditional Java class with private fields and getter/setters
    let result = `public class ${classNameUpper} {\n`;

    // Declare fields
    fields.forEach(({ fieldName, fieldType }) => {
      result += `  private ${fieldType} ${fieldName};\n`;
    });

    result += "\n";

    // Generate getter and setter methods
    fields.forEach(({ fieldName, fieldType }) => {
      const methodSuffix = toUpperCamelCase(fieldName);
      const isBoolean = fieldType === "boolean" || fieldType === "Boolean";
      const getterPrefix = isBoolean ? "is" : "get";

      result += `  public ${fieldType} ${getterPrefix}${methodSuffix}() {\n    return ${fieldName};\n  }\n\n`;
      result += `  public void set${methodSuffix}(${fieldType} ${fieldName}) {\n    this.${fieldName} = ${fieldName};\n  }\n\n`;
    });

    result += "}\n";
    return result;
  }
}

// Generate Kotlin data class code from a JSON object
function generateKotlinCode(obj, className = "Root") {
  const classNameUpper = toUpperCamelCase(className);
  const fields = [];

  // Process each key/value pair to define fields
  for (const key in obj) {
    const val = obj[key];
    const fieldName = toLowerCamelCase(key);
    const fieldType = determineKotlinType(key, val);
    fields.push({ fieldName, fieldType });
  }

  // Build the Kotlin data class string with all fields
  let result = `data class ${classNameUpper}(\n`;

  fields.forEach(({ fieldName, fieldType }, index) => {
    const isLast = index === fields.length - 1;
    result += `  val ${fieldName}: ${fieldType}${isLast ? "" : ","}\n`;
  });

  result += `)\n`;

  return result;
}

// Toggle the background image of a textarea based on whether it is empty or not
function toggleBackgroundImage(textarea, imageUrl) {
  textarea.style.backgroundImage = textarea.value.trim() === ""
    ? `url('${imageUrl}')`
    : "none";
}

// Show a validation error message on an input and clear it after 3 seconds
function showValidationError(input, message) {
  input.setCustomValidity(message);
  input.reportValidity();
  setTimeout(() => input.setCustomValidity(""), 3000);
}

// Main DOMContentLoaded event to initialize UI and bind event listeners
document.addEventListener("DOMContentLoaded", () => {
  const input1 = document.getElementById("code-input-1");
  const input2 = document.getElementById("code-input-2");
  const packageNameInput = document.getElementById("package-name-input");
  const javaRadio = document.getElementById("java");
  const kotlinRadio = document.getElementById("kotlin");

  // Containers for language-specific options
  const forcePrimitivesContainer = document.getElementById("force-primitives-container");
  const recordClassesContainer = document.getElementById("record-classes-container");
  const forceNonNullContainer = document.getElementById("force-non-null-container");

  // Control buttons
  const convertBtn = document.getElementById("convert-btn");
  const copyBtn = document.getElementById("copy-to-clipboard-btn");
  const downloadBtn = document.getElementById("download-btn");

  // Initialize background images for textareas
  toggleBackgroundImage(input1, 'json.svg');
  toggleBackgroundImage(input2, 'java.svg');

  // Update background image on user input
  input1.addEventListener("input", () => toggleBackgroundImage(input1, 'json.svg'));
  input2.addEventListener("input", () =>
    toggleBackgroundImage(input2, javaRadio.checked ? 'java.svg' : 'Kotlin.svg')
  );

  // Convert JSON input to Java or Kotlin code on button click
  convertBtn.addEventListener("click", function () {
    const jsonStr = input1.value.trim();
    if (!jsonStr) {
      showValidationError(input1, "Please enter JSON data");
      return;
    }

    let jsonObj;
    try {
      jsonObj = JSON.parse(jsonStr);
    } catch (e) {
      showValidationError(input1, "Invalid JSON: " + e.message);
      return;
    }

    // Generate code depending on selected language
    const code = javaRadio.checked ? generateJavaCode(jsonObj) : generateKotlinCode(jsonObj);
    input2.value = code;
    toggleBackgroundImage(input2, javaRadio.checked ? 'java.svg' : 'Kotlin.svg');
  });

  // Copy generated code to clipboard
  copyBtn?.addEventListener("click", () => {
    if (!input2.value.trim()) {
      showValidationError(input2, "Convert JSON before copy to clipboard");
      return;
    }
    input2.select();
    document.execCommand("copy");
  });

  // Download generated code as a file
  downloadBtn?.addEventListener("click", () => {
    if (!input2.value.trim()) {
      showValidationError(input2, "Convert JSON before starting download.");
      return;
    }

    const packageName = packageNameInput?.value.trim();
    const validPackage = /^[a-z]+(\.[a-z][a-z0-9]*)*$/.test(packageName);
    if (!validPackage) {
      showValidationError(packageNameInput, "Please enter correct package name");
      return;
    }

    const blob = new Blob([input2.value], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = javaRadio.checked ? "ConvertedCode.java" : "ConvertedCode.kt";
    link.click();
  });

  // Update output textarea background image based on selected language
  function updateIcon() {
    toggleBackgroundImage(input2, javaRadio.checked ? 'java.svg' : 'Kotlin.svg');
  }

  // Show/hide language-specific option controls based on selected language
  function updateLanguageOptions() {
    forcePrimitivesContainer.style.display = javaRadio.checked ? "block" : "none";
    recordClassesContainer.style.display = javaRadio.checked ? "block" : "none";
    forceNonNullContainer.style.display = kotlinRadio.checked ? "block" : "none";
  }

  // Update UI and save settings when language radio changes
  javaRadio.addEventListener("change", () => {
    updateIcon();
    updateLanguageOptions();
    saveSettings();
  });

  kotlinRadio.addEventListener("change", () => {
    updateIcon();
    updateLanguageOptions();
    saveSettings();
  });

  // Dark mode toggle button and persistence in localStorage
  const darkModeBtn = document.querySelector("#dark-mode-btn");
  const body = document.body;

  // Initialize dark mode state on page load
  if (localStorage.getItem("darkMode") === "enabled") {
    body.classList.add("dark-mode");
    darkModeBtn.innerHTML = `<img class="mode-icon" src="light_mode.svg" alt="Light Mode">Light Mode`;
  } else {
    darkModeBtn.innerHTML = `<img class="mode-icon" src="dark_mode.svg" alt="Dark Mode">Dark Mode`;
  }

  // Toggle dark mode and update UI and localStorage
  darkModeBtn.addEventListener("click", function () {
    body.classList.toggle("dark-mode");
    const enabled = body.classList.contains("dark-mode");
    darkModeBtn.innerHTML = enabled
      ? `<img class="mode-icon" src="light_mode.svg" alt="Light Mode">Light Mode`
      : `<img class="mode-icon" src="dark_mode.svg" alt="Dark Mode">Dark Mode`;
    localStorage.setItem("darkMode", enabled ? "enabled" : "disabled");
  });

  // References to annotation options for Gson, Jackson, Moshi
  const gsonOptions = [
    document.getElementById("expose-annotation"),
    document.getElementById("serialized-name")
  ];
  const jacksonOption = document.getElementById("jackson");
  const moshiOption = document.getElementById("moshi");

  // Update UI opacity for mutually exclusive serialization options
  function updateOpacity() {
    const isAnyGsonChecked = gsonOptions.some(opt => opt.checked);
    const isJacksonChecked = jacksonOption.checked;
    const isMoshiChecked = moshiOption.checked;

    gsonOptions.forEach(opt => {
      const label = document.querySelector(`label[for="${opt.id}"]`);
      label.style.opacity = (isJacksonChecked || isMoshiChecked) ? "0.5" : "1";
    });

    document.querySelector('label[for="jackson"]').style.opacity = (isAnyGsonChecked || isMoshiChecked) ? "0.5" : "1";
    document.querySelector('label[for="moshi"]').style.opacity = (isAnyGsonChecked || isJacksonChecked) ? "0.5" : "1";
  }

  // Handle clicking on serialization options to enforce exclusivity
  function handleClick(event) {
    const target = event.target;
    const isGsonClicked = gsonOptions.includes(target);
    const isJacksonClicked = target === jacksonOption;
    const isMoshiClicked = target === moshiOption;

    if (isGsonClicked && target.checked) {
      jacksonOption.checked = false;
      moshiOption.checked = false;
    } else if (isJacksonClicked && target.checked) {
      gsonOptions.forEach(opt => opt.checked = false);
      moshiOption.checked = false;
    } else if (isMoshiClicked && target.checked) {
      gsonOptions.forEach(opt => opt.checked = false);
      jacksonOption.checked = false;
    }

    updateOpacity();
    saveSettings();
  }

  // Attach event listeners to serialization option checkboxes
  [...gsonOptions, jacksonOption, moshiOption].forEach(opt => {
    opt.addEventListener("click", handleClick);
  });

  // Save current user settings to localStorage
  function saveSettings() {
    const settings = {
      language: javaRadio.checked ? "java" : "kotlin",
      options: {
        forcePrimitives: document.getElementById("force-primitives").checked,
        recordClasses: document.getElementById("record-classes").checked,
        forceNonNull: document.getElementById("force-non-null").checked,
      },
      gson: {
        expose: document.getElementById("expose-annotation").checked,
        serializedName: document.getElementById("serialized-name").checked,
      },
      jackson: jacksonOption.checked,
      moshi: moshiOption.checked,
      identicalProperties: document.getElementById("search-identical").checked
    };
    localStorage.setItem("converterSettings", JSON.stringify(settings));
  }

  // Restore saved user settings from localStorage or apply defaults
  function restoreSettings() {
    const saved = localStorage.getItem("converterSettings");

    const settings = saved ? JSON.parse(saved) : {
      language: "java",
      options: {
        forcePrimitives: true,
        recordClasses: true,
        forceNonNull: false,
      },
      gson: {
        expose: false,
        serializedName: false,
      },
      jackson: false,
      moshi: false,
      identicalProperties: true
    };

    if (settings.language === "java") {
      javaRadio.checked = true;
    } else {
      kotlinRadio.checked = true;
    }

    updateLanguageOptions();
    updateIcon();

    document.getElementById("force-primitives").checked = settings.options.forcePrimitives;
    document.getElementById("record-classes").checked = settings.options.recordClasses;
    document.getElementById("force-non-null").checked = settings.options.forceNonNull;

    document.getElementById("expose-annotation").checked = settings.gson.expose;
    document.getElementById("serialized-name").checked = settings.gson.serializedName;

    jacksonOption.checked = settings.jackson;
    moshiOption.checked = settings.moshi;

    document.getElementById("search-identical").checked = settings.identicalProperties || false;

    updateOpacity();
  }

  // Save settings when user toggles key option checkboxes
  [
    document.getElementById("force-primitives"),
    document.getElementById("record-classes"),
    document.getElementById("force-non-null"),
    document.getElementById("search-identical")
  ].forEach(opt => {
    opt.addEventListener("change", saveSettings);
  });

  // Load saved settings on page load
  restoreSettings();
});
